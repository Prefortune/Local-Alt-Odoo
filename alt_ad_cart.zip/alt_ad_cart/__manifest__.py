# -*- coding: utf-8 -*-
{
    'name': "alt_ad_cart",

    'summary': "Short (1 phrase/line) summary of the module's purpose",

    'description': """
Long description of module's purpose
    """,

    'author': "My Company",
    'website': "https://www.yourcompany.com",

    # Categories can be used to filter modules in modules listing
    # Check https://github.com/odoo/odoo/blob/15.0/odoo/addons/base/data/ir_module_category_data.xml
    # for the full list
    'category': 'Uncategorized',
    'version': '0.1',

    # any module necessary for this one to work correctly
    'depends': ['base','product','website_sale'],

    # always loaded
    'data': [
        'security/ir.model.access.csv',
        'views/alt_ad_cart_menu.xml',
        'views/alt_ad_cart_view.xml',
    ],
    # only loaded in demonstration mode
    'demo': [
        'demo/demo.xml',
    ],
    'assets': {
        'web.assets_frontend': [
           '/alt_ad_cart/static/src/css/ad_card_styles.scss',
           '/alt_ad_cart/static/src/js/alt_ad_inject.js'
        ],
    },
}

